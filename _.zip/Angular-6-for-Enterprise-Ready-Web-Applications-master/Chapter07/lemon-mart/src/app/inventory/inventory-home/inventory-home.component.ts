import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'app-inventory-home',
  template: `
    <p>
      inventory-home works!
    </p>
  `,
  styles: [],
})
export class InventoryHomeComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
