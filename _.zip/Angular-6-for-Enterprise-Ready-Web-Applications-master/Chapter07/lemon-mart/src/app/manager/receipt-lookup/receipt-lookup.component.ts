import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'app-receipt-lookup',
  templateUrl: './receipt-lookup.component.html',
  styleUrls: ['./receipt-lookup.component.css'],
})
export class ReceiptLookupComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
