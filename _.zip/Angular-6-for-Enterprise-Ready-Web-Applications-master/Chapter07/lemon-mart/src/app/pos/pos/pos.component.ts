import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'app-pos',
  templateUrl: './pos.component.html',
  styleUrls: ['./pos.component.css'],
})
export class PosComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
