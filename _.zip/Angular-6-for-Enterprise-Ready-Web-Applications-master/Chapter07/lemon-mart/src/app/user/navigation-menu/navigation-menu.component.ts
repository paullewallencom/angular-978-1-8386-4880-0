import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'app-navigation-menu',
  template: `
    <p>
      navigation-menu works!
    </p>
  `,
  styles: [],
})
export class NavigationMenuComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
