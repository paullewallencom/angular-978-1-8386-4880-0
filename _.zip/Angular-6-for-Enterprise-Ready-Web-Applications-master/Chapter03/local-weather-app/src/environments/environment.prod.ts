export const environment = {
  production: true,
  appId: '01ff1417eeb4a81b09ac68b15958d453',
  baseUrl: 'https://',
}
